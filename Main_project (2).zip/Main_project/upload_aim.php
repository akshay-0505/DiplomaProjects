<?php
// Check if a file has been uploaded
if(isset($_POST["submit"])) {
    
        $course=$_POST['course_name'];
        $course_code=$_POST['course_code'];
        $ass_no=$_POST['ass_no'];
        $aim=$_POST['ass_aim'];
        if(!empty($course) && !empty($course_code) && !empty($ass_no)&& !empty($aim)){
         $con = new mysqli('127.0.0.1', 'root', '', 'project_2k19');
        if(mysqli_connect_errno()) {
            die("MySQL connection failed: ". mysqli_connect_error());
        }
        $query_course=mysqli_query($con,"SELECT * FROM course WHERE course_code='".$course_code."'");
        $numrows1=mysqli_num_rows($query_course);
        if($numrows1!=0)
        {
        $row=mysqli_fetch_assoc($query_course);
        $table=$row['course_name']."asslist";

        $create_table="create table if not exists ".$table."(ass_id int(20) not null unique, course_code varchar(20) not null, ass_aim MEDIUMTEXT, pr_hrs int(10));";

        $created=mysqli_query($con,$create_table);
        echo $created;
        if($created)
        {

        $query1=mysqli_query($con,"SELECT * FROM '".$table."' where ass_id='".$ass_no."'");
        $numrows=mysqli_num_rows($query1);
        echo "$numrows";
        if($numrows==0)
        {
            $sql="INSERT INTO ".$table."(ass_id,course_code,ass_aim,pr_hrs) VALUES ('$ass_no','$course_code','$aim',2)";
            $result=mysqli_query($con,$sql);
            if($result){
                echo "Assignment Successfully Registered!";
            }else
            {
                echo "Failure!";
            }
        }
        }
        else
        {
            echo "Error to create Table!";
        }
    }

        else{
            echo "Course already exists!";
        }
    }
    else{
        echo "All fiels are Required!";
    }
    }
    
     ?>