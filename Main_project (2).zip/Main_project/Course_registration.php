<!DOCTYPE html>
<html>
<head>
	<title>course registration</title>
</head>
<body>
<form action="Course_registration.php" method="post">
	<table>
		<tr><td>Course Name:</td><td><input type="text" name="course_name"></td></tr><br><br>
		<tr>
	<td>Course Code:</td><td><select name="course_code">
  <option value="CM485">CM485</option>
  <option value="CM585">CM585</option>
  <option value="CM282">CM282</option>
  <option value="CM181">CM181</option>
</select></td></tr><br><br>


	<tr><td>No of Assignments:</td><td><input type="number" name="ass_no"></td></tr><br><br>
	
	<tr></td><td><input type="submit" name="submit" value="REGISTER"></td></tr><br><br>

	
	</table>
</form>
<?php 
		echo "<a href='RegisterStudent.php' ><button name='RegisterStudent' >RegisterStudent</button></a>";
	 ?>


<?php
// Check if submit pressed
// Start the session
session_start();


// Set session variables
$_SESSION['en_no']="1606033";
echo $_SESSION['en_no'];
$_SESSION["course"]="CM485";
$_SESSION["course_name"]="nma";
?>



<?php
// Check if a file has been uploaded
if(isset($_POST["submit"])) {
    
        $course=$_POST['course_name'];
        $course_code=$_POST['course_code'];
        $no_ass=$_POST['ass_no'];
        if(!empty($course) && !empty($course_code)){
         $con = new mysqli('127.0.0.1', 'root', '', 'project_2k19');
        if(mysqli_connect_errno()) {
            die("MySQL connection failed: ". mysqli_connect_error());
        }
 
        
        $query=mysqli_query($con,"SELECT * FROM course WHERE course_code='".$course_code."'");
        $numrows=mysqli_num_rows($query);
        if($numrows==0)
        {
            $sql="INSERT INTO course(course_code,course_name,no_of_ass) VALUES ('$course_code','$course','$no_ass')";
            $result=mysqli_query($con,$sql);
            if($result){
                echo "Course Successfully Registered!";
            }else
            {
                echo "Failure!";
            }
        }
        else{
            echo "Course already exists!";
        }
    }
    else{
        echo "All fiels are Required!";
    }
    }
    
    
?>
</body>
</html>