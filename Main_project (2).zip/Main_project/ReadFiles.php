<?php 
$dbLink=new mysqli("127.0.0.1",'root','','project_2k19');
	if(mysqli_connect_errno())
	{
		die("mysqli Connection Failed: ".mysqli_connet_error());
	}
	$sql="SELECT id,name,mime,size,created from file";
	$result=$dbLink->query($sql);
	if($result)
	{
		if($result->num_rows==0)
		{
			echo "<p>There are no files files in database</p>";
		}
		else
		{
			echo "<table width='100%'>
			<tr>
			<td><b>Name</b></td>
			<td><b>Mime</b></td>
			<td><b>Size</b></td>
			<td><b>Created</b></td>
			<td><b>&nbsp;</b></td>
			</tr>";
			while ($row=$result->fetch_assoc()) {
				# code...
				echo "<tr>
				<td><b>{$row['name']}</b></td>
				<td><b>{$row['mime']}</b></td>
				<td><b>{$row['size']}</b></td>
				<td><b>{$row['created']}</b></td>
				<td><b><a href='download.php?id={$row['id']}'>Download</a></b></td>
				
				</tr>";
			}
			echo "</table>";
		}
		$result->free();
		
	}
	else
	{
		echo "Error! SQL query Failed!";
		echo "<pre>{$dbLink->error}</pre>";

	}
	$dbLink->close();

 ?>