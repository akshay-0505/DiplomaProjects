<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "signin_table";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

	 $username = $_POST['uname'];
     $password = $_POST['password'];
     $c_password =$_POST['confirmPassword'];
     
$sql = "INSERT INTO signin (username, password, confirm_password)
VALUES ('$username','$password','$c_password')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>