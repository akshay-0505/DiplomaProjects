<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "signin_table";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
	/* $course_code = $_POST['course_code'];
$sql = "INSERT INTO login (course_code)
VALUES ('$course_code')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}*/
$message="";
if(count($_POST)>0) {
	$result = mysqli_query($conn,"SELECT * FROM signin WHERE username='" . $_POST["username"] . "' and password = '". $_POST["password"]."'");
	$count  = mysqli_num_rows($result);
	if($count==0) {
		echo "Invalid Username or Password!";
	} else {
		echo "You are successfully authenticated!";
		
	}
}

$conn->close();
?>