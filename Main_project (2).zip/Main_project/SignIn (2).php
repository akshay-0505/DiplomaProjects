<html>
<head>
<title> Online Assignment portal SignIn </title>
<link rel="stylesheet" type="text/css" >
<script language="javascript" type="text/javascript">
var count=0
var ch

function check()
{
with(document.forms.formSign)
{
if(uname.value.length>0)
{
password.disabled=false
ch=1
}
}
}
function goToStudent()
{
window.open('UI_student.html');
}

function goToTeacher()
{
window.open('UI_teacher.html');
}
function pass()
{
with(document.forms.formSign)
{
var repass=/^([A-Z|a-z]{2,})(\d{2,})(\W{1})$/
if(repass.test(password.value))
{
count=5
}
else
{
alert("Password Should Be Greater than 6 digits and should have atleast one Special Character")
}
if(count==5)
{
confirmPassword.disabled=false
ch=12
}
}
}

function confirm()
{
with(document.forms.formSign)
{
if(confirmPassword.value!=password.value)
{
alert("You've entered an incorrect password ! Please re-enter Your Password !")
}
else
{
ch=123
}
}
}

function Validate()
{
with(document.forms.formSign)
{
if(ch!=123)
{
alert("Please Check If you've Filled All the Details ")
}
else
{

var a = uname.value
var b = password.value
var d = new Date();
d.setMonth(d.getMonth()+3)
document.cookie=a +"=" + b +";expires = " + d.toGMTString()
window.open('login.html','','')
}
}
}

</script>
</head>

<body>
	
<br><br><br><div class="box"></div>
<img src="avatar.png" class="avatar" width="150px" height="150px">
<h1 align="center"> Sign In </h1><br><br><br>
<br>
<form name="formSign" method="post" action="Connection.php" >

<p>Username : <input type="text" name="uname" placeholder="Enter the Username" onblur="check()"  /><br></p>

<p>Password :<input type="password" name="password" placeholder="Enter the Password" disabled=true onblur="pass()" /><br></p>

<p>Confirm Password :<input type="password" name="confirmPassword" placeholder="Confirm Your Password"  onblur="confirm()" /><br></p><br>

<p><div class="b"><input type="submit" name="submit" value="Sign In" onclick="Validate()"  /><br></p><br></div>
<br>
Login in as :
<br>
<br>
<input type="submit" name="student" value="Student" onclick="goToStudent()">
&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="teacher" value="Teacher" onclick="goToTeacher()">

 	<br><br>
<div class="a"><a href="login_student.html">Already have an account?</a></div>
</form>

</body>
</html>