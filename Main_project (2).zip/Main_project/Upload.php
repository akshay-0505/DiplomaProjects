<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="s3.css">
	<title>Uploading Files</title>
</head>
<body>
	<form action="Add_File.php" method="POST" enctype="multipart/form-data">
		<center><h1>Choose a File:<input type="file" name="uploaded_file"></h1><br></center>
		<center><input type="submit" name="Upload File" value="Upload"></center>
	</form>

<p>
	<h3><center><a href="ReadFiles.php">See All Files</a></center></h3>
</p>
</body>
</html>