<script>
function goToStudent()
{
window.open('UI_student.html');
}

function goToTeacher()
{
window.open('UI_teacher.html');
}
</script>
Login as :
<br>
<br>
<input type="submit" name="student" value="Student" onclick="goToStudent()">
&nbsp;&nbsp;&nbsp;&nbsp;
<input type="submit" name="teacher" value="Teacher" onclick="goToTeacher()">
